
  const buttonChange = document.getElementById("button-change");
  const buttonRemove = document.getElementById("button-remove");
  const imagePic = document.getElementById("image-pic");
  const tableDetails = document.getElementById("table-details");
   //
  fetch("json/pataasth.json")
     .then(res =>res.json())
     .then(data =>{
  //
  


  buttonChange.addEventListener("click", function() {
    imagePic.classList.add("pataasth");
  });

  buttonRemove.addEventListener("click", function() {
    imagePic.classList.remove("pataasth");
  });

  const buttonRecipe1 = document.getElementById("buttonRecipe1");
  const buttonRecipe2 = document.getElementById("buttonRecipe2");
  const buttonRecipe3 = document.getElementById("buttonRecipe3");
  const imageRecipe = document.getElementById("Image-Recipe");
  const tableDetailsRecipe = document.getElementById("tableDetails");

  buttonRecipe1.addEventListener("click", function() {
    imageRecipe.src = "images/cookies.jpg";
    tableDetailsRecipe.innerHTML = "<tr><td>Step 1</td><td>Ingredients</td></tr><tr><td>Step 2</td><td>Instructions</td></tr>";
  });

  buttonRecipe2.addEventListener("click", function() {
    imageRecipe.src = "images/appleSkillet.jpg";
    tableDetailsRecipe.innerHTML = "<tr><td>Step 1</td><td>Ingredients</td></tr><tr><td>Step 2</td><td>Instructions</td></tr>";
  });

  buttonRecipe3.addEventListener("click", function() {
    imageRecipe.src = "images/cloudBread.jpg";
    tableDetailsRecipe.innerHTML = "<tr><td>Step 1</td><td>Ingredients</td></tr><tr><td>Step 2</td><td>Instructions</td></tr>";
  });

  //
  footerSave.addEventListener("click", () => {
    alert("Data saved to local storage");
    fetch("json/pataasth.json")
        .then(res => res.json())
        .then(data => {
            localStorage.setItem("data", JSON.stringify(data));
        });
      })
    });
    
