const buttonRecipe1 = document.getElementById("buttonRecipe1");
const buttonRecipe2 = document.getElementById("buttonRecipe2");
const buttonRecipe3 = document.getElementById("buttonRecipe3");
const imageRecipe = document.getElementById("imageRecipe");
const tableDetails = document.getElementById("tableDetails");
const data = JSON.parse(localStorage.getItem("data"));
const recipe1 = data.Recipe[0];
const recipe2 = data.Recipe[1];
const recipe3 = data.Recipe[2];
if (localStorage.getItem("selected-Recipe") === null) {
    tableDetails.innerHTML = "<tr><td>No Recipe Selected</td></tr>";
}
buttonRecipe1.addEventListener("click", () => {
    imageRecipe.src = `../images/${recipe1.picture}`;
    const details = Object.entries(recipe1).filter(([key, value]) => key !== "picture");
    let detailsHTML = "";
    details.forEach(([key, value]) => {
        detailsHTML += `<tr><td>${key}</td><td>${value}</td></tr>`;
    });
    tableDetails.innerHTML = detailsHTML;
});
buttonRecipe2.addEventListener("click", () => {
    imageRecipe.src = `../images/${recipe2.picture}`;
    const details = Object.entries(recipe2).filter(([key, value]) => key !== "picture");
    let detailsHTML = "";
    details.forEach(([key, value]) => {
        detailsHTML += `<tr><td>${key}</td><td>${value}</td></tr>`;
    });
    tableDetails.innerHTML = detailsHTML;
});
buttonRecipe3.addEventListener("click", () => {
    imageRecipe.src = `../images/${recipe3.picture}`;
    const details = Object.entries(recipe3).filter(([key, value]) => key !== "picture");
    let detailsHTML = "";
    details.forEach(([key, value]) => {
        detailsHTML += `<tr><td>${key}</td><td>${value}</td></tr>`;
    });
    tableDetails.innerHTML = detailsHTML;
});