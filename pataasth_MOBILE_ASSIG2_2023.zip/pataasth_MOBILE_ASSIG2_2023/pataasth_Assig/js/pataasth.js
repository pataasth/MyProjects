var authors = new Array();
var selectedAuthor;
var footer;
var header;


class Author {
	constructor(aname, pic) {
		this.aname = aname;
		this.pic = pic;
	}
}


class PersonalInformation {
	constructor(fName, uName, Id, program) {
		this.fName = fName;
		this.uName = uName;
		this.Id = Id;
		this.program = program;
	}
}


function loadContent() {
	fetch("./json/A2-JSON.json")
		.then(res => res.json())
		.then((authorData) => {
			console.log(authorData);
			lodFragments(authorData);
		});
}



function lodFragments(dataJSON) {


	const personalInformation = new PersonalInformation(dataJSON.SheridanData.FullName, dataJSON.SheridanData.UserName,
	dataJSON.SheridanData.StudentID, dataJSON.SheridanData.Program);

	document.getElementById("author-list").innerHTML = "";

	footer = "<a href= " + dataJSON.Reference + " target= \"_blank\">" + dataJSON.Reference + "</a>";

	header = "Assignment #2/ Winter 2023<br>Name:" + personalInformation.fName +	" Id:" + personalInformation.Id +
		" Login:" + personalInformation.uName +
		" Program:" + personalInformation.program;

	document.getElementById("footer").innerHTML = footer;

	document.getElementById("header").innerHTML = header;

	for (const [i, val] of dataJSON.Authors.entries()) {

		authors.push(new Author(val.authorName, val.picture))
		document.getElementById("author-list").innerHTML +=
			`<li>
		  		<a onclick='findIndex(${i})' href = 'authors-service/second.html'>
					${val.authorName}
		  			<img class='authorsPic' src='images/${val.picture}'>
				</a>
			</li>`;
	}

	setLocalStorageVariables();
}

function setLocalStorageVariables() {
	localStorage.setItem("authors", JSON.stringify(authors));
	localStorage.setItem("footer", footer);
	localStorage.setItem("header", header);
}

function findIndex(index) {
	localStorage.setItem("selectedAuthor", index);
}

