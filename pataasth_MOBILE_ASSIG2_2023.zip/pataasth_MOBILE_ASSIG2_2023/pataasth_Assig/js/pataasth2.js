var authorArray;
var selectedAuthor;
var authorPic;
var footer;
var header;

function authorDetailsContent() {
    // Fetch Author Details
    selectedAuthor = localStorage.getItem("selectedAuthor");
    authorArray = JSON.parse(localStorage.getItem("authors"));
    authorPic = authorArray[selectedAuthor].pic;

    var apiURI = `https://openlibrary.org/search/authors.json?q=${authorArray[selectedAuthor].aname}`;
    getAuthorData(apiURI);
}

function loadDataToElements(authorInfo) {
    document.querySelector("#pname").innerHTML = authorInfo.docs[0].name;
    document.querySelector("#pic").innerHTML =
        `<img id = "imgAuth" src='../images/${authorPic}'>`;
    document.querySelector("#birthdate").innerHTML = (authorInfo.docs[0].birth_date) ? authorInfo.docs[0].birth_date : "Not Specified";
    document.querySelector("#deathdate").innerHTML = (authorInfo.docs[0].death_date) ? authorInfo.docs[0].death_date : "Not Specified";
    document.querySelector("#topwork").innerHTML = authorInfo.docs[0].top_work;

    
    header = localStorage.getItem("header");
    document.getElementById("header").innerHTML = header;

   
    footer = localStorage.getItem("footer");
    document.getElementById("footer").innerHTML = footer;
}

function getAuthorData(apiURI) {
    const xhttp = new XMLHttpRequest();
    xhttp.open("GET", apiURI, true);
    xhttp.send();

    xhttp.onload = function () {
        data = this.responseText;
        authorInfo = JSON.parse(data);
        console.log(authorInfo);
        loadDataToElements(authorInfo);
    }
}
